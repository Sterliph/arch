nvidia-settings -q gpucoretemp -t | tr -d '\n' | cut -c1-2
echo ℃
